from django import template
from django.template.defaultfilters import stringfilter
import re,markdown

register = template.Library()

@stringfilter
def len_text(value):
    text = None
    if len(value) > 200:
        text = value[:200] + "……"
    else:
        text = value + "……"
    return text

@stringfilter
def len_text_long(value):
    text = None
    if len(value) > 400:
        text = value[:400] + "……"
    else:
        text = value + "……"
    return text
@stringfilter
def markdown_auto(value):
    context = markdown.markdown(
        text=value,
        extensions=[
            'markdown.extensions.extra',
            'markdown.extensions.codehilite',
            'markdown.extensions.toc',
        ])
    return context


register.filter("len_text", len_text)
register.filter("len_long", len_text_long)
register.filter("md_auto",markdown_auto)