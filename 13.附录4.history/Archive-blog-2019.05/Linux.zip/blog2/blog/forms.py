from django import forms
from simditor.fields import RichTextFormField
from . import models

class Comment(forms.Form):
    context_text = RichTextFormField()
    email = forms.EmailField()