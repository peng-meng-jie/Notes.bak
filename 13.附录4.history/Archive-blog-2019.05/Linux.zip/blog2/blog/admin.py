from django.contrib import admin

from . import models

class AdminTid(admin.ModelAdmin):
    # to tags and textclass
    filter_horizontal = ('tid', )

class AdminText(admin.ModelAdmin):
    list_display = ('name', 'create_time', )

admin.site.register([
    models.Text,
],AdminText,)

admin.site.register(
    models.Comment,
)

admin.site.register([
    models.Tags,models.TextClass,
],AdminTid)

