from django.db import models
from django.urls import reverse

from allauth.account.models import EmailAddress
from simditor.fields import RichTextField

class ManagerText(models.Manager):
    def time_list(self):
        return self.get_queryset().all().order_by('-create_time')

class Text(models.Model):
    name = models.CharField(max_length=50)
    uid = models.ForeignKey(EmailAddress,on_delete=models.CASCADE)
    create_time = models.DateTimeField()
    changer_time = models.DateTimeField(blank=True,null=True)
    text = RichTextField()
    objects = ManagerText()

    class Meta:
        ordering = ('-create_time', )

    def get_lookup(self):
        return reverse('blog_look',kwargs={
            "pk":self.pk,"on": "text",
        })

    def __str__(self):
        return self.name

class Tags(models.Model):
    name = models.CharField(max_length=30)
    tid = models.ManyToManyField('Text', )

    def get_lookup(self):
        return reverse('blog_look',kwargs={
                "pk":self.pk,"on":"tag",
            })

    def __str__(self):
        return  self.name

class TextClass(models.Model):
    name = models.CharField(max_length=30)
    tid = models.ManyToManyField('Text', )

    def get_lookup(self):
        return reverse('blog_look',kwargs={
                 "pk":self.pk, "on":"cls",
            })
    def __str__(self):
        return  self.name

class Comment(models.Model):
    # uid = models.OneToOneField(EmailAddress,on_delete=models.CASCADE)
    email = models.EmailField()
    tid = models.ForeignKey('Text',on_delete=models.CASCADE)
    text = RichTextField()
    create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('create_time', )

    def __str__(self):
        text = "[ {} ] {}"
        return text.format(self.email,self.tid)

