from django.apps import AppConfig


class MytestConfig(AppConfig):
    name = 'mytest'
