from django import forms
from simditor.fields import RichTextFormField
from . import models

class Comment(forms.Form):
    # 富文本自定义模块-配置

    context_text = RichTextFormField()
    email = forms.EmailField()

class Login(forms.Form):
    # 登录表单
    name = models.BlogUser.name
    email = models.BlogUser.eamil
    password = models.BlogUser.pad