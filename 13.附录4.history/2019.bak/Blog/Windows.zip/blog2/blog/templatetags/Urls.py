import requests
from lxml import etree



def gethtml(urls=None,header=None):
    # 获取 html
    html = None
    try:
        html = requests.get(urls,headers=header)
        assert html.status_code == 200
        return html.text
    except:
        print("异常！")
        return None

def html_xpath(html=None):
    # 解析HTML
    if html != None:
        h = etree.parse(html)
        # print(h)
        audio =  h.xpath("//audiod/")
        return audio
    return None

if __name__ == '__main__':
    headers = {
        'UserAgent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3',
        'Referer': 'http://m.kugou.com/rank/info/8888',
        'Cookie': 'UM_distinctid=161d629254c6fd-0b48b34076df63-6b1b1279-1fa400-161d629255b64c; kg_mid=cb9402e79b3c2b7d4fc13cbc85423190; Hm_lvt_aedee6983d4cfc62f509129360d6bb3d=1523818922; Hm_lpvt_aedee6983d4cfc62f509129360d6bb3d=1523819865; Hm_lvt_c0eb0e71efad9184bda4158ff5385e91=1523819798; Hm_lpvt_c0eb0e71efad9184bda4158ff5385e91=1523820047; musicwo17=kugou'
    }

    # 指定的酷狗 urls
    urls = 'http://www.kugou.com/song/#hash=98F356CA141636DBAE32EBDFC641F982&album_id=974514'

    audio = html_xpath(gethtml(urls,header=headers))
    # print(audio)
