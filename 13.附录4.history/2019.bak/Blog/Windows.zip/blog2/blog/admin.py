from django.contrib import admin

from . import models

class AdminTid(admin.ModelAdmin):
    # to tags and textclass || 指定到标签和分类 后台定制
    filter_horizontal = ('tid', )

class AdminText(admin.ModelAdmin):
    # 用户后台表
    list_display = ('name', 'create_time', )

admin.site.register([
    models.Text,
],AdminText,)

admin.site.register(
    models.Comment,
)

admin.site.register([
    models.Tags,models.TextClass,
],AdminTid)



