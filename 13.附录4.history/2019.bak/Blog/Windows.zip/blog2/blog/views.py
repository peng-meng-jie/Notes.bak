from django.shortcuts import render, get_object_or_404,reverse
from django.views.generic import ListView
from django.core import paginator
from django.http import HttpResponse

from . import models, forms
from datetime import datetime


def list_pags(request):
    models_list = models.Text.objects.time_list()


class Index(ListView):
    model = models.Text()
    queryset = models.Text.objects.all()
    template_name = 'blog/blog.html'
    context_object_name = "blog"

    paginate_by = 10

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super(Index, self).get_context_data(**kwargs)
        context['cls'] = models.TextClass.objects.all()
        context['tag'] = models.Tags.objects.all()
        context['objects_list'] = models.Text.objects.time_list()
        return context


def text(request, pk=None, on=None):
    obj_model, alls = (None, None)
    if on == "cls":
        # to cls
        obj_model = models.TextClass
    elif on == "tag":
        # to tag
        obj_model = models.Tags
    elif on == "text":
        # to_text
        if request.method == "POST":
            # to comments
            f = forms.Comment(data=request.POST)
            if f.is_valid():
                f.tid = get_object_or_404(models.Text,pk=pk)
                models.Comment.objects.get_queryset().create(
                    tid=f.tid,
                    text=f.cleaned_data['context_text'],
                    email=f.cleaned_data['email'],
                ).save()
                html = '<a href="javascript:history.go(-1)">返回上一页</a> '
                return HttpResponse(html)

        get_text = get_object_or_404(models.Text, pk=pk)
        get_comment = models.Comment.objects.get_queryset().filter(tid=get_text)
        Form = forms.Comment()
        return render(request, 'blog/text.html', {
            "text": get_text,
            "forms": Form,
            "comment": get_comment,
        })
    if on is not None:
        alls = get_object_or_404(obj_model, pk=pk)

        _cls = models.TextClass.objects.all()
        _tag = models.Tags.objects.all()
    return render(request, 'blog/blog_cls_tags.html', {
        "context": alls.tid.all(), "tag": _tag, "cls": _cls,
    })


def tags(request, pk=None):
    tags = get_object_or_404(models.Tags, pk=pk)
    return render(
        request, 'blog/text.html',
        context={"tags": tags}
    )
